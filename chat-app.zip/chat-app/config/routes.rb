Rails.application.routes.draw do
    root to:"titles#index"
    get "/titles/new", to:"titles#new"
    post "/titles/create", to:"titles#create"
    delete "/titles/:id", to:"titles#destroy"
    
    get "/chats/:id/index", to:"chats#index"
    post "/chats/:id/create", to:"chats#create"
end
