class TitlesController < ApplicationController
    def index
        @titles = Title.all
    end
    
    def new
        
    end
    
    def create
        Title.create(title:params[:titles][:title])
        redirect_to("/")
    end
    
    def destroy
        title = Title.find(params[:id])
        title.destroy
        redirect_to("/")
    end
end
