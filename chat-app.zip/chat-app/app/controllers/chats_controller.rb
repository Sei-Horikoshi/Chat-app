class ChatsController < ApplicationController
    def index
        @title = Title.find(params[:id])
        @chats = Chat.where(title_id: @title.id)
    end
    
    def create
        Chat.create(body:params[:comments][:comment], title_id:params[:id])
        redirect_to("/chats/#{params[:id]}/index")
    end
end
