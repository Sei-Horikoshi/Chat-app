class Title < ApplicationRecord
    has_many :chats
end
