class Chat < ApplicationRecord
    belongs_to :title
end
